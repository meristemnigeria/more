import '../node_modules/bootstrap/dist/css/bootstrap.min.css'
import './App.css'
import logo_1 from './assets/images/more_logo_1.png'
import logo_2 from './assets/images/more_logo_2.png'
import pic_1 from './assets/images/pic_1.png'
import pic_2 from './assets/images/pic_2.png'
import pic_3 from './assets/images/pic_3.png'
import pic_4 from './assets/images/pic_4.png'
import pic_5 from './assets/images/pic_5.png'
import pic_6 from './assets/images/pic_6.png'
import pic_7 from './assets/images/pic_7.png'
import icon_focus from './assets/images/icons_focus.png'
import icon_bulb from './assets/images/icons_bulb.png'
import icon_goal from './assets/images/icons_goal.png'
import man_pose from './assets/images/man_pose.png'
import man_pose_1 from './assets/images/man_pose_1.png'
import woman_pose from './assets/images/woman_pose.png'
import woman_pose_1 from './assets/images/woman_pose_1.png'
import linkedin from './assets/images/linkedin.png'
import twitter from './assets/images/twitter.png'
import youtube from './assets/images/youtube.png'
import AccordionItem from './components/AccordionItem'
import Accordion from './components/Accordion'

function App() {

    const year = new Date().getFullYear()

    return (
        <div className="container-fluid px-0">
            <div className="banner-bg">
                <nav className="navbar navbar-expand-lg navbar-light bg-light fixed-top frost-bg" style={{ padding: 20 }}>
                    <div className="container">
                        <a className="navbar-brand">
                            <img src={logo_1} alt="" width="149" height="60" />
                        </a>

                        <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                            aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                            <span className="navbar-toggler-icon"></span>
                        </button>
                        <div className="collapse navbar-collapse" id="navbarNav">
                            <ul className="navbar-nav" style={{ flexGrow: 1, justifyContent: 'center' }}>
                                <li className="nav-item">
                                    <a className="nav-link active" aria-current="page" href="#">Home</a>
                                </li>
                                <li className="nav-item">
                                    <a className="nav-link" href="#our-programme">Our Pathways</a>
                                </li>
                                <li className="nav-item">
                                    <a className="nav-link" href="#faq">FAQs</a>
                                </li>
                            </ul>

                            <form className="d-flex">
                                <button className="btn btn-primary" type="submit">Join
                                    Waitlist</button>
                            </form>
                        </div>
                    </div>
                </nav>

                <div className="msg" style={{ paddingBottom: 61 }}>
                    <div className="main-message">
                        <div className="display-3 ht1">Growth <br /> inspired by learning</div>
                        <div className="ht2">Helping young and ambitious people acquire knowledge they require to bring
                            them closer to where they want to be financially</div>
                        <button className="btn btn-primary" type="submit" style={{ marginTop: 30 }}>Join
                            Waitlist</button>
                    </div>
                </div>

                <div className="pics-collage-container" style={{ padding: '0 30px' }}>
                    <div className="container d-flex">
                        <div className="pics-collage">
                            <div className="pic-item" id="pic-1">
                                <div className="pic-item-a" style={{ backgroundImage: `url(${pic_1})` }}>
                                </div>
                            </div>
                            <div className="pic-item" id="pic-23">
                                <div className="pic-item-b" style={{ backgroundImage: `url(${pic_2})`, marginBottom: 16 }}>
                                </div>
                                <div className="pic-item-c" style={{ backgroundImage: `url(${pic_3})`, marginTop: 16 }}>
                                </div>
                            </div>
                            <div className="pic-item" id="pic-4">
                                <div className="pic-item-d" style={{ backgroundImage: `url(${pic_4})` }}>
                                </div>
                            </div>
                            <div className="pic-item" id="pic-56">
                                <div className="pic-item-c" style={{ backgroundImage: `url(${pic_5})`, marginBottom: 16 }}>
                                </div>
                                <div className="pic-item-b" style={{ backgroundImage: `url(${pic_6})`, marginTop: 16 }}>
                                </div>
                            </div>
                            <div className="pic-item" id="pic-7">
                                <div className="pic-item-a" style={{ backgroundImage: `url(${pic_7})`, float: 'right' }}>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>

                <div className="vision-mission">
                    <div className="container">
                        <div className="row h-100">
                            <div className="col-12 col-md-6 h-100 mb-3">
                                <div className="row h-50"
                                    ref={el => {
                                        if (el) {
                                            el.style.setProperty('min-height', '246px', 'important');
                                            el.style.setProperty('padding-bottom', '6px', 'important');
                                        }
                                    }}>
                                    <div className="card p-0">
                                        <div className="card-body"
                                            ref={el => {
                                                if (el) {
                                                    el.style.setProperty('padding', '25px 30px', 'important');
                                                }
                                            }}>
                                            <div className="icon-container">
                                                <img src={icon_bulb} alt="Vision"
                                                    style={{ height: 40, width: 40 }} />
                                            </div>
                                            <h4>Vision</h4>
                                            <p>MORE aims to be the distinct and preferred platform for professional investment
                                                and
                                                entrepreneurship competence development. </p>
                                        </div>
                                    </div>
                                </div>
                                <div className="row h-50"
                                    ref={el => {
                                        if (el) {
                                            el.style.setProperty('min-height', '284px', 'important');
                                            el.style.setProperty('padding-top', '6px', 'important');
                                        }
                                    }}>
                                    <div className="card p-0">
                                        <div className="card-body"
                                            ref={el => {
                                                if (el) {
                                                    el.style.setProperty('padding', '25px 30px', 'important');
                                                }
                                            }}>
                                            <div className="icon-container">
                                                <img src={icon_focus} alt="Vision"
                                                    style={{ height: 40, width: 40 }} />
                                            </div>
                                            <h4>Mission</h4>
                                            <p>We do this by nurturing and grooming future investors and entrepreneurs through
                                                knowledge creation, knowledge sharing, and knowledge utilization for optimal
                                                value
                                                creation and sustainability. </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="col-12 col-md-6 mb-3" id="col2">
                                <div className="card h-100"
                                    ref={el => {
                                        if (el) {
                                            el.style.setProperty('min-height', '554px', 'important');
                                        }
                                    }}>
                                    <div className="card-body">
                                        <div className="icon-container">
                                            <img src={icon_goal} alt="Vision" style={{ height: 40, width: 40 }} />
                                        </div>
                                        <h4>Our Focus Areas</h4>
                                        <ul>
                                            <li>Equipping young potential investors and entrepreneurs with knowledge and skill
                                                to
                                                practice their enterprise.</li>
                                            <li>Making investments, investing, and entrepreneurship (more) attractive to young
                                                people.</li>
                                            <li>Providing all-round/end-to-end business support to budding and experienced
                                                investors
                                                and entrepreneurs.</li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>

                <div className="our-programme" id="our-programme">
                    <div className="container">
                        <div className="row">
                            <h3 className="h2 pb-4">Our Pathways</h3>
                            <div className="col-12">
                                <div className="card">
                                    <div className="card-body" style={{ minHeight: 618 }}>
                                        <div className="row g-0" id="card-container">
                                            <div className="col-12 col-xl-8">
                                                <h4 className="h4">Join Our <br />Investment Programme</h4>
                                                <p>The Investment pathway exposes potential and existing investors to the
                                                    nitty-gritty of investment opportunities, pitfalls, strategy, and practical
                                                    investment tips.
                                                    There are seven (7) modules in the pathway:</p>
                                                <div className="row">
                                                    <div className="col">
                                                        <ul>
                                                            <li>Financial Literacy</li>
                                                            <li>Investment Analysis</li>
                                                            <li>Investment vehicles</li>
                                                            <li>The Meristem Brand</li>
                                                        </ul>
                                                    </div>
                                                    <div className="col">
                                                        <ul>
                                                            <li>Investment landscape</li>
                                                            <li>Economic Theory and Practice</li>
                                                            <li>Building and Sustaining Generational Wealth</li>
                                                        </ul>
                                                    </div>
                                                </div>
                                                <button className="btn btn-primary" style={{ padding: '16px 30px' }}>Join
                                                    Waitlist</button>
                                            </div>
                                            <div className="col-4 d-none d-xl-block">
                                                <div className="img-stack">
                                                    <div className="img-layer-1">
                                                    </div>
                                                    <div className="img-image" style={{ background: `url(${man_pose_1})` }}>
                                                        <img src={man_pose} style={{ height: 432 }} />
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div className="col-12" style={{ marginTop: 40 }}>
                                <div className="card">
                                    <div className="card-body" style={{ minHeight: 618 }}>
                                        <div className="row g-0" id="card-container">
                                            <div className="col-5 d-none d-xl-block">
                                                <div className="img-stack">
                                                    <div className="img-layer-1">
                                                    </div>
                                                    <div className="img-image" style={{ background: `url(${woman_pose_1})` }}>
                                                        <img src={woman_pose} style={{ height: 432 }} />
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="col-12 col-xl-7">
                                                <h4 className="h4">Join Our <br />Entrepreneurship Programme</h4>
                                                <p>The Entrepreneurship pathway is an advanced pathway for learners who have
                                                    completed the Investment pathways and want to explore their options in
                                                    entrepreneurship.
                                                    There are generally three (3) tracks under the entrepreneurship pathways.
                                                    You
                                                    are expected to take the general entrepreneurship track and any of the
                                                    start-up
                                                    or scale-up track.
                                                    The start-up track is for any person or group with a new idea that has never
                                                    been tested in the market. The scale-up track is for those with existing
                                                    businesses and desire expansion.</p>
                                                <button className="btn btn-primary mt-4" style={{ padding: '16px 30px' }}>Join
                                                    Waitlist</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>

                </div>

                <div className="faq p-2 py-6 p-sm-4" id="faq">
                    <div className="container">
                        <div className="row">
                            <h3 className="h3 pb-2 pb-sm-4">FREQUENTLY ASKED QUESTIONS</h3>
                            <div className="col-12 col-md-12 mx-auto">
                                <Accordion accordionId='faq'>
                                    <>
                                        <AccordionItem id={`${1}`} parentAccordionId='faq' heading='What is MORE?'>
                                            <><p>
                                                MORE stands for <b>M</b>eristem <b>O</b>rientation for <b>R</b>ising <b>E</b>ntrepreneurs.
                                                MORE is aimed at improving the quality of investment and entrepreneurship training among young people with a focus on growing, preserving, and transferring wealth.
                                            </p>
                                                <p>
                                                    MORE is exclusively provided by <a href='https://meristemng.com/'>Meristem Securities Limited</a> in advancing our value relevance as a socially responsible organisation.
                                                </p>
                                            </>
                                        </AccordionItem>
                                        <AccordionItem id={`${2}`} parentAccordionId='faq' heading='MORE has two (2) pathways?'>
                                            <p>
                                                <ol>
                                                    <li><b>Investment:</b> This pathway prepares you to become an investor by taking you through the rudiments and other aspects of investment. Ultimately, you will become a confident and informed investor.</li>
                                                    <li><b>Entrepreneurship:</b> This pathway builds your capacity to become an entrepreneur and strengthens you to thrive as an entrepreneur.</li>
                                                </ol>
                                            </p>
                                        </AccordionItem>
                                        <AccordionItem id={`${3}`} parentAccordionId='faq' heading='Why are there two pathways in MORE?'>
                                            <p>
                                                We believe that individuals have different inclinations, with some preferring to be investors and others aspiring to be entrepreneurs. There are also those who can effectively combine both paths. MORE provides the means to expand your wealth, catering to your desired approach and choice, be it through investment, entrepreneurship, or a combination of both.
                                            </p>
                                        </AccordionItem>
                                        <AccordionItem id={`${4}`} parentAccordionId='faq' heading='What is the timeframe for the completion of MORE?'>
                                            <p>
                                                The <b>Investment</b> pathway will run for 13 weeks.<br />
                                                The <b>Entrepreneurship</b> pathway will run for 17 weeks.
                                            </p>
                                        </AccordionItem>
                                        <AccordionItem id={`${5}`} parentAccordionId='faq' heading='What are covered in the pathways?'>
                                            <p>
                                                <b>The Investment Pathways cover modules such as</b> Financial Literacy, Investment landscape, Investment vehicles, Investment Analysis, Building and Sustaining Generational Wealth as well as the Meristem brand.<br />
                                                <b>The Entrepreneurship Pathways cover modules such as</b> business awareness, business intelligence, legal and compliance requirements, business and funding models, pitch development and other pervasive soft skills required for starting and running a venture. This pathway also includes a facilitation and mentoring component. <br /> <br />
                                                Learners will participate in exciting learning activities, community discussion as well as engaging assessments.
                                            </p>
                                        </AccordionItem>
                                        <AccordionItem id={`${6}`} parentAccordionId='faq' heading='Who qualifies to enrol for MORE?'>
                                            <p>
                                                MORE is a youth-focused programme; hence any young person is eligible to enrol. Specifically, persons aged 16 – 40 years are eligible.
                                            </p>
                                        </AccordionItem>
                                        <AccordionItem id={`${7}`} parentAccordionId='faq' heading='What is the process for completing MORE?'>
                                            <>
                                                <p>Enrolees must start with the Investment Pathway before proceeding to the Entrepreneurship Pathway. Only persons who complete the Investment Pathway can be admitted to the Entrepreneurship Pathway.
                                                </p>
                                                <p>For both pathways, there are learning modules, which starts with an introductory clip, then learning materials which are visual, graphical and illustrational. </p>
                                            </>
                                        </AccordionItem>
                                        <AccordionItem id={`${8}`} parentAccordionId='faq' heading='What do I need to enrol for MORE?'>
                                            <p>Your conviction, passion, and commitment are the main ingredients you need. You will also need a smartphone and/or a Laptop/PC with internet access. </p>
                                        </AccordionItem>
                                        <AccordionItem id={`${9}`} parentAccordionId='faq' heading='What is the cost implication for enrolling for MORE?'>
                                            <p>MORE is freely provided and delivered by <a href="http://meristemng.com/">Meristem Securities Limited</a> in furtherance of its commitment to enriching youthful experience and helping young people grow their wealth.</p>
                                        </AccordionItem>
                                        <AccordionItem id={`${10}`} parentAccordionId='faq' heading='How will MORE be delivered?'>
                                            <p>MORE will be delivered fully online. This is to ensure increased access to all young people and enable a diverse pool of potential investors and entrepreneurs to be beneficiaries of the project.</p>
                                        </AccordionItem>
                                        <AccordionItem id={`${11}`} parentAccordionId='faq' heading='How is the content of MORE like?'>
                                            <>
                                                <p>MORE is not your regular academic course. It offers an engaging and enjoyable learning experience, providing dynamic content that introduces you to the worlds of investment and entrepreneurship in a relaxed and comfortable atmosphere.</p>
                                                <p>With MORE, you'll have access to visually appealing graphics, informative videos, and supplemental materials such as TED Talks and other inspiring contents from creators and experts worldwide.</p>
                                                <p>What sets MORE apart is its focus on delivering locally tailored content that maintains global relevance. Furthermore, assessments in MORE are designed to be game-based and easy to complete while still being informative and enriching.</p>
                                            </>
                                        </AccordionItem>
                                        <AccordionItem id={`${12}`} parentAccordionId='faq' heading='What deployment model will be used for MORE?'>
                                            <p>MORE pathways will be delivered in streams/cohorts to facilitate group learning and encourage community discussion and accountability. Adequate information will be available on the website about start and end dates for each stream/cohort.</p>
                                        </AccordionItem>
                                        <AccordionItem id={`${13}`} parentAccordionId='faq' heading='What if I am unable to complete any of the pathways?'>
                                            <p>We encourage all enrolees to complete at least the Investment Pathway. However, if you are unable to complete any of the pathways, your spot will still be available whenever you are ready within the stream’s timeframe. If you miss your stream’s timeline, you will be required to start again with another stream. </p>
                                        </AccordionItem>
                                        <AccordionItem id={`${14}`} parentAccordionId='faq' heading='Do I get a certificate for completing MORE?'>
                                            <p>Asides the knowledge and competence you gain for completing MORE, you get occasional badges which you can display on your social media pages as well as include in your CV. And yes! You get a certificate at the completion of the investment pathways and the entrepreneurship pathways, which are endorsed by the GMD of Meristem Securities Limited. A certificate of completion is auto-generated at the completion of the pathway and will be available on your dashboard for subsequent viewing or downloads.</p>
                                        </AccordionItem>
                                        <AccordionItem id={`${15}`} parentAccordionId='faq' heading='What cogent benefits do I stand to gain from MORE?'>
                                            <p>
                                                <ol>
                                                    <li>Completing the investment pathways gives you confidence to invest in both the Nigerian market and global markets.
                                                    </li>
                                                    <li>You also get to become more visible to employers.
                                                    </li>
                                                    <li>Individuals who pass through the entrepreneurship pathways and have groundbreaking business ideas will be provided with funding, and business support to start or scale their businesses.
                                                    </li>
                                                    <li>There are other bonuses attached to completing specific aspects of the pathways including meeting certain thresholds.
                                                    </li>
                                                </ol>
                                            </p>
                                        </AccordionItem>
                                        <AccordionItem id={`${16}`} parentAccordionId='faq' heading='How does the MORE Leader board work?'>
                                            <p>A transparent leader board will record learners’ progress in a stream/cohort and rewards will be given to top leaders. </p>
                                        </AccordionItem>
                                        <AccordionItem id={`${17}`} parentAccordionId='faq' heading='How do I contact support?'>
                                            <p>We have a robust support team to answer your questions and help you navigate the platform for a rich and enjoyable experience. Kindly reach out using the following means:
                                                &nbsp;<a href="mailto:more@meristemng.com">Email: more@meristemng.com</a>
                                            </p>
                                        </AccordionItem>
                                    </>
                                </Accordion>
                            </div>
                        </div>
                    </div>

                </div>

                <div className="footer">
                    <div className="container">
                        <div className="d-flex flex-row justify-content-between align-items-center"
                            style={{ flexGrow: 1, flexShrink: 1, flexWrap: 'wrap' }}>
                            <div id="motto" style={{ width: 332 }}>
                                <img src={logo_2} alt="Logo" style={{ height: 55 }} />
                                <p style={{ marginTop: 15 }}>Helping young and ambitious people acquire knowledge they
                                    require
                                    to
                                    bring them closer to where they want to be financially.</p>
                            </div>
                            <div className="" style={{ alignSelf: 'flex-end', marginBottom: 12, flexGrow: 1 }}>
                                <div className="navbar navbar-expand-lg navbar-dark">
                                    <div className="collapse navbar-collapse" id="navbarNav">
                                        <ul className="navbar-nav" style={{ flexGrow: 1, justifyContent: 'center' }}>
                                            <li className="nav-item">
                                                <a className="nav-link active" aria-current="page" href="#">Home</a>
                                            </li>
                                            <li className="nav-item">
                                                <a className="nav-link" href="#our-programme">Our Pathways</a>
                                            </li>
                                            <li className="nav-item">
                                                <a className="nav-link" href="#faq">FAQs</a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div style={{ width: 130, alignSelf: 'flex-end', marginBottom: 32, paddingLeft: 6 }}>
                                <div className="d-flex flex-row justify-content-between">
                                    <a href="https://linkedin.com"><img src={linkedin} alt="Linkedin"
                                        style={{ height: 28 }} /></a>
                                    <a href="https://twitter.com"><img src={twitter} alt="Twitter"
                                        style={{ height: 28 }} /></a>
                                    <a href="https://youtube.com"><img src={youtube} alt="Youtube"
                                        style={{ height: 28 }} /></a>
                                </div>
                            </div>
                        </div>
                        <div className="line">
                        </div>
                        <p className="copyright">
                            &copy; {year + ''} <b>Meristem</b></p>
                    </div>

                </div>
            </div>
        </div>
    )
}

export default App
