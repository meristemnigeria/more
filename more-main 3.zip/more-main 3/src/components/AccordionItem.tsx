type PageProps = {
    id: string
    parentAccordionId: string
    heading: string
    children: JSX.Element
}

function AccordionItem({ id, parentAccordionId, heading, children }: PageProps) {
    return (
        <div className="accordion-item">
            <h2 className="accordion-header" id={`flush-heading-${id}`}>
                <button className="accordion-button collapsed shadow-none" type="button"
                    data-bs-toggle="collapse" data-bs-target={`#flush-collapse-${id}`}
                    aria-expanded="false" aria-controls={`flush-collapse-${id}`}>
                    {heading}
                </button>
            </h2>
            <div id={`flush-collapse-${id}`} className="accordion-collapse collapse"
                aria-labelledby={`flush-heading-${id}`} data-bs-parent={`#accordion-${parentAccordionId}`}>
                <div className="accordion-body">
                    {children}
                </div>
            </div>
        </div>
    )
}

export default AccordionItem;