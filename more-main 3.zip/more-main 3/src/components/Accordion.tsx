type PageProps = {
    accordionId: string
    children: JSX.Element
}

function Accordion({accordionId, children}: PageProps){
    return (
        <div className="accordion accordion-flush" id={`accordion-${accordionId}`}>
            {children}
        </div>
    )
}

export default Accordion;